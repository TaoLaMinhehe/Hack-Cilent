/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.client.keybinds;

import java.util.Objects;

import com.mojang.blaze3d.platform.InputConstants;

public class Keybind implements Comparable<Keybind>
{
	private final String key;
	private final String commands;
	
	public Keybind(String key, String commands)
	{
		this.key = Objects.requireNonNull(key);
		this.commands = Objects.requireNonNull(commands);
	}
	
	public String getKey()
	{
		return key;
	}
	
	public String getCommands()
	{
		return commands;
	}
	
	@Override
	public int compareTo(Keybind o)
	{
		return key.compareToIgnoreCase(o.key);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(obj == null || !(obj instanceof Keybind))
			return false;
		
		Keybind otherKeybind = (Keybind)obj;
		
		return key.equalsIgnoreCase(otherKeybind.key);
	}
	
	@Override
	public int hashCode()
	{
		return key.hashCode();
	}
	
	@Override
	public String toString()
	{
		return getDisplayKey(key) + " -> " + commands;
	}
	
	/**
	 * Converts a key identifier like "key.keyboard.w" or "key.mouse.left" to a
	 * translated display string like "W" or "Left Button".
	 */
	public static String getDisplayKey(String key)
	{
		try
		{
			return InputConstants.getKey(key).getDisplayName().getString();
			
		}catch(IllegalArgumentException e)
		{
			return key;
		}
	}
}
