/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.client.hacks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.client.Category;
import net.client.SearchTags;
import net.client.events.UpdateListener;
import net.client.hack.Hack;
import net.client.settings.CheckboxSetting;
import net.client.settings.FaceTargetSetting;
import net.client.settings.FaceTargetSetting.FaceTarget;
import net.client.settings.SliderSetting;
import net.client.settings.SliderSetting.ValueDisplay;
import net.client.settings.SwingHandSetting;
import net.client.settings.SwingHandSetting.SwingHand;
import net.client.settings.TakeItemsFromSetting;
import net.client.settings.TakeItemsFromSetting.TakeItemsFrom;
import net.client.settings.filterlists.AnchorAuraFilterList;
import net.client.settings.filterlists.EntityFilterList;
import net.client.util.BlockUtils;
import net.client.util.ChatUtils;
import net.client.util.EntityUtils;
import net.client.util.FakePlayerEntity;
import net.client.util.InventoryUtils;
import net.client.util.RotationUtils;

@SearchTags({"anchor aura", "CrystalAura", "crystal aura"})
public final class AnchorAuraHack extends Hack implements UpdateListener
{
	private final SliderSetting range =
		new SliderSetting("Range", "description.wurst.setting.anchoraura.range",
			6, 1, 6, 0.05, ValueDisplay.DECIMAL);
	
	private final CheckboxSetting autoPlace =
		new CheckboxSetting("Auto-place anchors",
			"description.wurst.setting.anchoraura.auto-place_anchors", true);
	
	private final CheckboxSetting checkLOS =
		new CheckboxSetting("Check line of sight",
			"description.wurst.setting.anchoraura.check_line_of_sight", false);
	
	private final FaceTargetSetting faceTarget =
		FaceTargetSetting.withPacketSpam(this, FaceTarget.OFF);
	
	private final SwingHandSetting swingHand =
		new SwingHandSetting(this, SwingHand.CLIENT);
	
	private final TakeItemsFromSetting takeItemsFrom =
		TakeItemsFromSetting.withoutHands(this, TakeItemsFrom.INVENTORY);
	
	private final EntityFilterList entityFilters =
		AnchorAuraFilterList.create();
	
	public AnchorAuraHack()
	{
		super("AnchorAura");
		
		setCategory(Category.COMBAT);
		addSetting(range);
		addSetting(autoPlace);
		addSetting(checkLOS);
		addSetting(faceTarget);
		addSetting(swingHand);
		addSetting(takeItemsFrom);
		
		entityFilters.forEach(this::addSetting);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(MC.level.dimensionType().attributes()
			.applyModifier(EnvironmentAttributes.RESPAWN_ANCHOR_WORKS, false))
		{
			ChatUtils.error("Respawn anchors don't explode in this dimension.");
			setEnabled(false);
		}
		
		ArrayList<BlockPos> anchors = getNearbyAnchors();
		
		Map<Boolean, ArrayList<BlockPos>> anchorsByCharge = anchors.stream()
			.collect(Collectors.partitioningBy(this::isChargedAnchor,
				Collectors.toCollection(ArrayList::new)));
		
		ArrayList<BlockPos> chargedAnchors = anchorsByCharge.get(true);
		ArrayList<BlockPos> unchargedAnchors = anchorsByCharge.get(false);
		
		if(!chargedAnchors.isEmpty())
		{
			detonate(chargedAnchors);
			return;
		}
		
		int maxInvSlot = takeItemsFrom.getMaxInvSlot();
		
		if(!unchargedAnchors.isEmpty()
			&& InventoryUtils.indexOf(Items.GLOWSTONE, maxInvSlot) >= 0)
		{
			charge(unchargedAnchors);
			// TODO: option to wait until next tick?
			detonate(unchargedAnchors);
			return;
		}
		
		if(!autoPlace.isChecked() || InventoryUtils
			.indexOf(Items.RESPAWN_ANCHOR, takeItemsFrom.getMaxInvSlot()) == -1)
			return;
		
		ArrayList<Entity> targets = getNearbyTargets();
		ArrayList<BlockPos> newAnchors = placeAnchorsNear(targets);
		
		if(!newAnchors.isEmpty() && InventoryUtils.indexOf(Items.GLOWSTONE,
			takeItemsFrom.getMaxInvSlot()) >= 0)
		{
			// TODO: option to wait until next tick?
			charge(newAnchors);
			detonate(newAnchors);
		}
	}
	
	private ArrayList<BlockPos> placeAnchorsNear(ArrayList<Entity> targets)
	{
		ArrayList<BlockPos> newAnchors = new ArrayList<>();
		
		boolean shouldSwing = false;
		for(Entity target : targets)
		{
			ArrayList<BlockPos> freeBlocks = getFreeBlocksNear(target);
			
			for(BlockPos pos : freeBlocks)
				if(placeAnchor(pos))
				{
					shouldSwing = true;
					newAnchors.add(pos);
					
					// TODO optional speed limit(?)
					break;
				}
		}
		
		if(shouldSwing)
			swingHand.swing(InteractionHand.MAIN_HAND);
		
		return newAnchors;
	}
	
	private void detonate(ArrayList<BlockPos> chargedAnchors)
	{
		if(isSneaking())
			return;
		
		InventoryUtils.selectItem(stack -> !stack.is(Items.GLOWSTONE),
			takeItemsFrom.getMaxInvSlot());
		if(MC.player.isHolding(Items.GLOWSTONE))
			return;
		
		boolean shouldSwing = false;
		
		for(BlockPos pos : chargedAnchors)
			if(rightClickBlock(pos))
				shouldSwing = true;
			
		if(shouldSwing)
			swingHand.swing(InteractionHand.MAIN_HAND);
	}
	
	private void charge(ArrayList<BlockPos> unchargedAnchors)
	{
		if(isSneaking())
			return;
		
		InventoryUtils.selectItem(Items.GLOWSTONE,
			takeItemsFrom.getMaxInvSlot());
		if(!MC.player.isHolding(Items.GLOWSTONE))
			return;
		
		boolean shouldSwing = false;
		
		for(BlockPos pos : unchargedAnchors)
			if(rightClickBlock(pos))
				shouldSwing = true;
			
		if(shouldSwing)
			swingHand.swing(InteractionHand.MAIN_HAND);
	}
	
	private boolean rightClickBlock(BlockPos pos)
	{
		Vec3 eyesPos = RotationUtils.getEyesPos();
		Vec3 posVec = Vec3.atCenterOf(pos);
		double distanceSqPosVec = eyesPos.distanceToSqr(posVec);
		
		for(Direction side : Direction.values())
		{
			Vec3 hitVec = posVec
				.add(Vec3.atLowerCornerOf(side.getUnitVec3i()).scale(0.5));
			double distanceSqHitVec = eyesPos.distanceToSqr(hitVec);
			
			// check if hitVec is within range (6 blocks)
			if(distanceSqHitVec > 36)
				continue;
			
			// check if side is facing towards player
			if(distanceSqHitVec >= distanceSqPosVec)
				continue;
			
			if(checkLOS.isChecked()
				&& !BlockUtils.hasLineOfSight(eyesPos, hitVec))
				continue;
			
			faceTarget.face(hitVec);
			
			// place block
			IMC.getInteractionManager().rightClickBlock(pos, side, hitVec);
			
			return true;
		}
		
		return false;
	}
	
	private boolean placeAnchor(BlockPos pos)
	{
		Vec3 eyesPos = RotationUtils.getEyesPos();
		double rangeSq = range.getValueSq();
		Vec3 posVec = Vec3.atCenterOf(pos);
		double distanceSqPosVec = eyesPos.distanceToSqr(posVec);
		
		for(Direction side : Direction.values())
		{
			BlockPos neighbor = pos.relative(side);
			
			// check if neighbor can be right clicked
			if(!isClickableNeighbor(neighbor))
				continue;
			
			Vec3 dirVec = Vec3.atLowerCornerOf(side.getUnitVec3i());
			Vec3 hitVec = posVec.add(dirVec.scale(0.5));
			
			// check if hitVec is within range
			if(eyesPos.distanceToSqr(hitVec) > rangeSq)
				continue;
			
			// check if side is visible (facing away from player)
			if(distanceSqPosVec > eyesPos.distanceToSqr(posVec.add(dirVec)))
				continue;
			
			if(checkLOS.isChecked()
				&& !BlockUtils.hasLineOfSight(eyesPos, hitVec))
				continue;
			
			InventoryUtils.selectItem(Items.RESPAWN_ANCHOR,
				takeItemsFrom.getMaxInvSlot());
			if(!MC.player.isHolding(Items.RESPAWN_ANCHOR))
				return false;
			
			faceTarget.face(hitVec);
			
			// place block
			IMC.getInteractionManager().rightClickBlock(neighbor,
				side.getOpposite(), hitVec);
			
			return true;
		}
		
		return false;
	}
	
	private ArrayList<BlockPos> getNearbyAnchors()
	{
		Vec3 eyesVec = RotationUtils.getEyesPos().subtract(0.5, 0.5, 0.5);
		BlockPos center = BlockPos.containing(RotationUtils.getEyesPos());
		int rangeI = range.getValueCeil();
		double rangeSq = Mth.square(range.getValue() + 0.5);
		
		Comparator<BlockPos> furthestFromPlayer = Comparator
			.<BlockPos> comparingDouble(
				pos -> eyesVec.distanceToSqr(Vec3.atLowerCornerOf(pos)))
			.reversed();
		
		return BlockUtils.getAllInBoxStream(center, rangeI).filter(
			pos -> eyesVec.distanceToSqr(Vec3.atLowerCornerOf(pos)) <= rangeSq)
			.filter(pos -> BlockUtils.getBlock(pos) == Blocks.RESPAWN_ANCHOR)
			.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<Entity> getNearbyTargets()
	{
		double rangeSq = range.getValueSq();
		
		Comparator<Entity> furthestFromPlayer =
			Comparator.<Entity> comparingDouble(EntityUtils::distanceToHitboxSq)
				.reversed();
		
		Stream<Entity> stream = StreamSupport
			.stream(MC.level.entitiesForRendering().spliterator(), false)
			.filter(e -> !e.isRemoved())
			.filter(e -> e instanceof LivingEntity
				&& ((LivingEntity)e).getHealth() > 0)
			.filter(e -> e != MC.player)
			.filter(e -> !(e instanceof FakePlayerEntity))
			.filter(e -> !WURST.getFriends().contains(e.getName().getString()))
			.filter(e -> EntityUtils.distanceToHitboxSq(e) <= rangeSq);
		
		stream = entityFilters.applyTo(stream);
		
		return stream.sorted(furthestFromPlayer)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private ArrayList<BlockPos> getFreeBlocksNear(Entity target)
	{
		Vec3 eyesVec = RotationUtils.getEyesPos().subtract(0.5, 0.5, 0.5);
		double rangeSq = Mth.square(range.getValue() + 0.5);
		
		BlockPos center = target.blockPosition();
		int rangeI = 2;
		
		AABB targetBB = target.getBoundingBox();
		Vec3 targetEyesVec =
			target.position().add(0, target.getEyeHeight(target.getPose()), 0);
		
		Comparator<BlockPos> closestToTarget =
			Comparator.<BlockPos> comparingDouble(
				pos -> targetEyesVec.distanceToSqr(Vec3.atCenterOf(pos)));
		
		return BlockUtils.getAllInBoxStream(center, rangeI).filter(
			pos -> eyesVec.distanceToSqr(Vec3.atLowerCornerOf(pos)) <= rangeSq)
			.filter(this::isReplaceable).filter(this::hasClickableNeighbor)
			.filter(pos -> !targetBB.intersects(new AABB(pos)))
			.sorted(closestToTarget)
			.collect(Collectors.toCollection(ArrayList::new));
	}
	
	private boolean isReplaceable(BlockPos pos)
	{
		return BlockUtils.getState(pos).canBeReplaced();
	}
	
	private boolean hasClickableNeighbor(BlockPos pos)
	{
		return isClickableNeighbor(pos.above())
			|| isClickableNeighbor(pos.below())
			|| isClickableNeighbor(pos.north())
			|| isClickableNeighbor(pos.east())
			|| isClickableNeighbor(pos.south())
			|| isClickableNeighbor(pos.west());
	}
	
	private boolean isClickableNeighbor(BlockPos pos)
	{
		return BlockUtils.canBeClicked(pos)
			&& !BlockUtils.getState(pos).canBeReplaced();
	}
	
	private boolean isChargedAnchor(BlockPos pos)
	{
		return BlockUtils.getState(pos)
			.getOptionalValue(RespawnAnchorBlock.CHARGE).orElse(0) > 0;
	}
	
	private boolean isSneaking()
	{
		return MC.player.isShiftKeyDown()
			|| WURST.getHax().sneakHack.isEnabled();
	}
}
