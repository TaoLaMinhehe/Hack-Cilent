/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.client.hacks.newchunks;

import java.util.List;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.AABB;
import net.client.WurstRenderLayers;
import net.client.settings.SliderSetting;
import net.client.util.RegionPos;
import net.client.util.RenderUtils;

public final class NewChunksReasonsRenderer
{
	private final SliderSetting drawDistance;
	
	public NewChunksReasonsRenderer(SliderSetting drawDistance)
	{
		this.drawDistance = drawDistance;
	}
	
	public void buildBuffer(VertexConsumer buffer, List<BlockPos> reasons)
	{
		ChunkPos camChunkPos =
			ChunkPos.containing(RenderUtils.getCameraBlockPos());
		RegionPos region = RegionPos.of(camChunkPos);
		int drawDistance = this.drawDistance.getValueI();
		
		for(BlockPos pos : reasons)
		{
			ChunkPos chunkPos = ChunkPos.containing(pos);
			if(chunkPos.getChessboardDistance(camChunkPos) > drawDistance)
				continue;
			
			AABB box = new AABB(pos).move(-region.x(), 0, -region.z());
			RenderUtils.drawSolidBox(buffer, box, 0xFFFFFFFF);
		}
	}
	
	public RenderType getLayer()
	{
		return WurstRenderLayers.ESP_QUADS;
	}
}
