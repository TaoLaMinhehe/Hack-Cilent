/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.client.mixin;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.client.InputFaker;
import net.client.InputFaker.TempRealInput;
import net.client.WurstClient;
import net.client.event.EventManager;
import net.client.events.AirStrafingSpeedListener.AirStrafingSpeedEvent;
import net.client.events.IsPlayerInWaterListener.IsPlayerInWaterEvent;
import net.client.events.KnockbackListener.KnockbackEvent;
import net.client.events.PlayerMoveListener.PlayerMoveEvent;
import net.client.events.PostMotionListener.PostMotionEvent;
import net.client.events.PreMotionListener.PreMotionEvent;
import net.client.events.UpdateListener.UpdateEvent;
import net.client.hack.HackList;
import net.client.mixinterface.ILocalPlayer;

@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin extends AbstractClientPlayer
	implements ILocalPlayer
{
	@Shadow
	@Final
	protected Minecraft minecraft;
	
	private Screen tempCurrentScreen;
	
	private LocalPlayerMixin(WurstClient wurst, ClientLevel world,
		GameProfile profile)
	{
		super(world, profile);
	}
	
	@Inject(method = "tick()V", at = @At("HEAD"))
	private void onTickHead(CallbackInfo ci)
	{
		InputFaker.swapIfNeeded();
	}
	
	@Inject(method = "tick()V", at = @At("RETURN"))
	private void onTickReturn(CallbackInfo ci)
	{
		InputFaker.restoreIfNeeded();
	}
	
	@Inject(method = "rideTick()V", at = @At("HEAD"))
	private void onRideTickHead(CallbackInfo ci)
	{
		InputFaker.swapIfNeeded();
	}
	
	@Inject(method = "rideTick()V", at = @At("RETURN"))
	private void onRideTickReturn(CallbackInfo ci)
	{
		InputFaker.restoreIfNeeded();
	}
	
	@Inject(method = "tick()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/AbstractClientPlayer;tick()V",
			ordinal = 0))
	private void onTick(CallbackInfo ci)
	{
		try(TempRealInput _ = new TempRealInput())
		{
			EventManager.fire(UpdateEvent.INSTANCE);
		}
	}
	
	/**
	 * This mixin makes AutoSprint's "Omnidirectional Sprint" setting work.
	 */
	@WrapOperation(method = "aiStep()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/ClientInput;hasForwardImpulse()Z",
			ordinal = 0))
	private boolean wrapHasForwardMovement(ClientInput input,
		Operation<Boolean> original)
	{
		if(WurstClient.INSTANCE.getHax().autoSprintHack.shouldOmniSprint())
			return input.getMoveVector().length() > 1e-5F;
		
		return original.call(input);
	}
	
	/**
	 * Makes you keep sprinting when using an item while NoSlowdown is enabled.
	 */
	@WrapOperation(method = "aiStep()V",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/LocalPlayer;isSlowDueToUsingItem()Z",
			ordinal = 0))
	private boolean wrapTickMovementItemUse(LocalPlayer instance,
		Operation<Boolean> original)
	{
		if(WurstClient.INSTANCE.getHax().noSlowdownHack.isEnabled())
			return false;
		
		return original.call(instance);
	}
	
	/**
	 * Prevents item-use movement slowdown while NoSlowdown is enabled.
	 */
	@WrapOperation(
		method = "modifyInput(Lnet/minecraft/world/phys/Vec2;)Lnet/minecraft/world/phys/Vec2;",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z",
			ordinal = 0))
	private boolean wrapModifyInputItemUse(LocalPlayer instance,
		Operation<Boolean> original)
	{
		if(WurstClient.INSTANCE.getHax().noSlowdownHack.isEnabled())
			return false;
		
		return original.call(instance);
	}
	
	@Inject(method = "sendPosition()V", at = @At("HEAD"))
	private void onSendMovementPacketsHEAD(CallbackInfo ci)
	{
		EventManager.fire(PreMotionEvent.INSTANCE);
	}
	
	@Inject(method = "sendPosition()V", at = @At("TAIL"))
	private void onSendMovementPacketsTAIL(CallbackInfo ci)
	{
		EventManager.fire(PostMotionEvent.INSTANCE);
	}
	
	@Inject(
		method = "move(Lnet/minecraft/world/entity/MoverType;Lnet/minecraft/world/phys/Vec3;)V",
		at = @At("HEAD"))
	private void onMove(MoverType type, Vec3 offset, CallbackInfo ci)
	{
		EventManager.fire(PlayerMoveEvent.INSTANCE);
	}
	
	@Inject(method = "isAutoJumpEnabled()Z",
		at = @At("HEAD"),
		cancellable = true)
	private void onIsAutoJumpEnabled(CallbackInfoReturnable<Boolean> cir)
	{
		if(!WurstClient.INSTANCE.getHax().stepHack.isAutoJumpAllowed())
			cir.setReturnValue(false);
	}
	
	/**
	 * When PortalGUI is enabled, this mixin temporarily sets the current screen
	 * to null to prevent the updateNausea() method from closing it.
	 */
	@Inject(method = "handlePortalTransitionEffect(Z)V",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/Minecraft;screen:Lnet/minecraft/client/gui/screens/Screen;",
			opcode = Opcodes.GETFIELD,
			ordinal = 0))
	private void beforeTickNausea(boolean fromPortalEffect, CallbackInfo ci)
	{
		if(!WurstClient.INSTANCE.getHax().portalGuiHack.isEnabled())
			return;
		
		tempCurrentScreen = minecraft.screen;
		minecraft.screen = null;
	}
	
	/**
	 * This mixin restores the current screen as soon as the updateNausea()
	 * method is done looking at it.
	 */
	@Inject(method = "handlePortalTransitionEffect(Z)V",
		at = @At(value = "FIELD",
			target = "Lnet/minecraft/client/player/LocalPlayer;portalEffectIntensity:F",
			opcode = Opcodes.GETFIELD,
			ordinal = 1))
	private void afterTickNausea(boolean fromPortalEffect, CallbackInfo ci)
	{
		if(tempCurrentScreen == null)
			return;
		
		minecraft.screen = tempCurrentScreen;
		tempCurrentScreen = null;
	}
	
	/**
	 * This mixin allows AutoSprint to enable sprinting even when the player is
	 * too hungry.
	 */
	@Inject(method = "isSprintingPossible(Z)Z",
		at = @At("HEAD"),
		cancellable = true)
	private void onCanSprint(boolean allowTouchingWater,
		CallbackInfoReturnable<Boolean> cir)
	{
		if(WurstClient.INSTANCE.getHax().autoSprintHack.shouldSprintHungry())
			cir.setReturnValue(true);
	}
	
	/**
	 * Getter method for what used to be airStrafingSpeed.
	 * Overridden to allow for the speed to be modified by hacks.
	 */
	@Override
	protected float getFlyingSpeed()
	{
		AirStrafingSpeedEvent event =
			new AirStrafingSpeedEvent(super.getFlyingSpeed());
		EventManager.fire(event);
		return event.getSpeed();
	}
	
	@Override
	public void lerpMotion(Vec3 vec)
	{
		KnockbackEvent event = new KnockbackEvent(vec.x, vec.y, vec.z);
		EventManager.fire(event);
		super.lerpMotion(new Vec3(event.getX(), event.getY(), event.getZ()));
	}
	
	@Override
	public boolean isInWater()
	{
		boolean inWater = super.isInWater();
		IsPlayerInWaterEvent event = new IsPlayerInWaterEvent(inWater);
		EventManager.fire(event);
		
		return event.isInWater();
	}
	
	@Override
	public boolean isTouchingWaterBypass()
	{
		return super.isInWater();
	}
	
	@Override
	protected float getJumpPower()
	{
		return super.getJumpPower() + WurstClient.INSTANCE.getHax().highJumpHack
			.getAdditionalJumpMotion();
	}
	
	/**
	 * This is the part that makes SafeWalk work.
	 */
	@Override
	protected boolean isStayingOnGroundSurface()
	{
		return super.isStayingOnGroundSurface()
			|| WurstClient.INSTANCE.getHax().safeWalkHack.isEnabled();
	}
	
	/**
	 * This mixin allows SafeWalk to sneak visibly when the player is
	 * near a ledge.
	 */
	@Override
	protected Vec3 maybeBackOffFromEdge(Vec3 movement, MoverType type)
	{
		Vec3 result = super.maybeBackOffFromEdge(movement, type);
		
		if(movement != null)
			WurstClient.INSTANCE.getHax().safeWalkHack
				.onClipAtLedge(!movement.equals(result));
		
		return result;
	}
	
	@Override
	public boolean hasEffect(Holder<MobEffect> effect)
	{
		HackList hax = WurstClient.INSTANCE.getHax();
		
		if(effect == MobEffects.NIGHT_VISION
			&& hax.fullbrightHack.isNightVisionActive())
			return true;
		
		if(effect == MobEffects.LEVITATION && hax.noLevitationHack.isEnabled())
			return false;
		
		if(effect == MobEffects.BLINDNESS && hax.antiBlindHack.isEnabled())
			return false;
		
		if(effect == MobEffects.DARKNESS && hax.antiBlindHack.isEnabled())
			return false;
		
		return super.hasEffect(effect);
	}
	
	@Override
	public MobEffectInstance getEffect(Holder<MobEffect> effect)
	{
		HackList hax = WurstClient.INSTANCE.getHax();
		
		if(effect == MobEffects.LEVITATION && hax.noLevitationHack.isEnabled())
			return null;
		
		return super.getEffect(effect);
	}
	
	@Override
	public float maxUpStep()
	{
		return WurstClient.INSTANCE.getHax().stepHack
			.adjustStepHeight(super.maxUpStep());
	}
	
	@Override
	public double blockInteractionRange()
	{
		HackList hax = WurstClient.INSTANCE.getHax();
		if(hax == null || !hax.reachHack.isEnabled())
			return super.blockInteractionRange();
		
		return hax.reachHack.getReachDistance();
	}
	
	@Override
	public double entityInteractionRange()
	{
		HackList hax = WurstClient.INSTANCE.getHax();
		if(hax == null || !hax.reachHack.isEnabled())
			return super.entityInteractionRange();
		
		return hax.reachHack.getReachDistance();
	}
	
	/**
	 * This is the part that makes Liquids work.
	 */
	@WrapOperation(
		method = "pick(Lnet/minecraft/world/entity/Entity;DDF)Lnet/minecraft/world/phys/HitResult;",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/world/entity/Entity;pick(DFZ)Lnet/minecraft/world/phys/HitResult;",
			ordinal = 0))
	private static HitResult liquidsRaycast(Entity instance, double maxDistance,
		float tickDelta, boolean includeFluids, Operation<HitResult> original)
	{
		if(!WurstClient.INSTANCE.getHax().liquidsHack.isEnabled())
			return original.call(instance, maxDistance, tickDelta,
				includeFluids);
		
		return original.call(instance, maxDistance, tickDelta, true);
	}
}
