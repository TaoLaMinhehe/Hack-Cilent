/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.client.clickgui.components;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.client.clickgui.ClickGui;
import net.client.clickgui.Component;
import net.client.clickgui.Window;
import net.client.clickgui.screens.EditBlockScreen;
import net.client.settings.BlockSetting;
import net.client.util.RenderUtils;
import net.client.util.text.WText;

public final class BlockComponent extends Component
{
	private static final ClickGui GUI = WURST.getGui();
	private static final Font TR = MC.font;
	private static final int BLOCK_WIDTH = 24;
	
	private final BlockSetting setting;
	
	public BlockComponent(BlockSetting setting)
	{
		this.setting = setting;
		setWidth(getDefaultWidth());
		setHeight(getDefaultHeight());
	}
	
	@Override
	public void handleMouseClick(double mouseX, double mouseY, int mouseButton,
		MouseButtonEvent context)
	{
		if(mouseX < getX() + getWidth() - BLOCK_WIDTH)
			return;
		
		switch(mouseButton)
		{
			case GLFW.GLFW_MOUSE_BUTTON_LEFT:
			MC.setScreen(new EditBlockScreen(MC.screen, setting));
			break;
			
			case GLFW.GLFW_MOUSE_BUTTON_RIGHT:
			setting.resetToDefault();
			break;
		}
	}
	
	@Override
	public void render(GuiGraphicsExtractor context, int mouseX, int mouseY,
		float partialTicks)
	{
		int x1 = getX();
		int x2 = x1 + getWidth();
		int x3 = x2 - BLOCK_WIDTH;
		int y1 = getY();
		int y2 = y1 + getHeight();
		
		boolean hovering = isHovering(mouseX, mouseY, x1, y1, x2, y2);
		boolean hText = hovering && mouseX < x3;
		boolean hBlock = hovering && mouseX >= x3;
		
		// tooltip
		if(hText)
			GUI.setTooltip(setting.getWrappedDescription(200));
		else if(hBlock)
			GUI.setTooltip(getBlockTooltip());
		
		// background
		int bgColor =
			RenderUtils.toIntColor(GUI.getBgColor(), GUI.getOpacity());
		context.fill(x1, y1, x2, y2, bgColor);
		
		context.guiRenderState.up();
		
		// text
		String name = setting.getName() + ":";
		context.text(TR, name, x1, y1 + 2, GUI.getTxtColor(), false);
		
		// block
		ItemStack stack = new ItemStack(setting.getBlock());
		RenderUtils.drawItem(context, stack, x3, y1, true);
	}
	
	private boolean isHovering(int mouseX, int mouseY, int x1, int y1, int x2,
		int y2)
	{
		Window parent = getParent();
		boolean scrollEnabled = parent.isScrollingEnabled();
		int scroll = scrollEnabled ? parent.getScrollOffset() : 0;
		
		return mouseX >= x1 && mouseY >= y1 && mouseX < x2 && mouseY < y2
			&& mouseY >= -scroll && mouseY < parent.getHeight() - 13 - scroll;
	}
	
	private String getBlockTooltip()
	{
		Block block = setting.getBlock();
		BlockState state = block.defaultBlockState();
		ItemStack stack = new ItemStack(block);
		
		String translatedName = stack.isEmpty()
			? WText.translated("gui.wurst.generic.unknown_block").toString()
			: stack.getHoverName().getString();
		String tooltip = "\u00a76Name:\u00a7r " + translatedName;
		
		String blockId = setting.getBlockName();
		tooltip += "\n\u00a76ID:\u00a7r " + blockId;
		
		int blockNumber = Block.getId(state);
		tooltip += "\n\u00a76Block #:\u00a7r " + blockNumber;
		
		tooltip +=
			"\n\n" + WText.translated("gui.wurst.generic.left_click_to_edit");
		tooltip +=
			"\n" + WText.translated("gui.wurst.generic.right_click_to_reset");
		
		return tooltip;
	}
	
	@Override
	public int getDefaultWidth()
	{
		return TR.width(setting.getName() + ":") + BLOCK_WIDTH + 4;
	}
	
	@Override
	public int getDefaultHeight()
	{
		return BLOCK_WIDTH;
	}
}
